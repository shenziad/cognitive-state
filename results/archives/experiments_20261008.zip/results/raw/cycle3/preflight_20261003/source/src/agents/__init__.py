"""Agent execution interfaces."""
